from MainPackage import some_main_script
from MainPackage.SubPackage import my_sub_script

some_main_script.report_main()
my_sub_script.sub_report()